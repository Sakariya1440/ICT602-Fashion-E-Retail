package service;

import domain.InventoryItem;
import domain.Reservation;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import repository.InventoryRepository;

import java.util.Optional;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

import static org.junit.jupiter.api.Assertions.*;

/**
 * JUnit 5 Test Class for InventoryService.
 * This class tests the functional logic and the concurrency control mechanism
 * for the complex Inventory Reservation Module (Part A).
 */
class InventoryServiceTest {

    private InventoryService inventoryService;
    private InventoryRepository inventoryRepository;
    private static final String PROD_ID = "P001";
    private static final int INITIAL_STOCK = 10;

    // A lightweight Mock implementation of the Repository interface for testing.
    static class MockRepository implements InventoryRepository {
        InventoryItem item;

        @Override
        public Optional<InventoryItem> findByProductId(String productId) {
            if (item != null && item.getProductId().equals(productId)) {
                return Optional.of(item);
            }
            return Optional.empty();
        }

        @Override
        public InventoryItem save(InventoryItem item) {
            this.item = item;
            return item;
        }
    }

    /**
     * Executes before every test case to ensure the stock is reset.
     * This addresses the 'Invalid Stock State' risk in the Test Plan.
     */
    @BeforeEach
    void setUp() {
        inventoryRepository = new MockRepository();
        // Initialize with 10 items for a fresh test environment
        inventoryRepository.save(new InventoryItem(PROD_ID, INITIAL_STOCK));
        inventoryService = new InventoryService(inventoryRepository);
    }

    @Test
    void testReserveSuccess() {
        System.out.println("Running TC_001: Reserve Success");
        Reservation res = inventoryService.reserve(PROD_ID, 3);

        assertNotNull(res);

        // Verify state: 10 - 3 = 7 available
        InventoryItem item = inventoryRepository.findByProductId(PROD_ID).get();
        assertEquals(7, item.getAvailableQty(), "Available quantity must decrease by reservation amount.");
        assertEquals(3, item.getReservedQty(), "Reserved quantity must increase by reservation amount.");
    }

    @Test
    void testReserveInsufficientStock() {
        System.out.println("Running TC_002: Insufficient Stock");
        // Test reserving more than the available 10 items
        Exception exception = assertThrows(IllegalStateException.class, () -> {
            inventoryService.reserve(PROD_ID, 15);
        });

        assertTrue(exception.getMessage().contains("Insufficient stock"));
    }

    @Test
    void testCommitReservation() {
        System.out.println("Running TC_003: Commit Reservation");
        Reservation res = inventoryService.reserve(PROD_ID, 2);
        inventoryService.commit(res.getId());

        // Stock was 10. Reserved 2 (Avail 8, Res 2). Committed 2 (Avail 8, Res 0).
        InventoryItem item = inventoryRepository.findByProductId(PROD_ID).get();
        assertEquals(8, item.getAvailableQty(), "Available stock should remain correct after commit.");
        assertEquals(0, item.getReservedQty(), "Reserved quantity must be cleared after successful commit.");
    }

    @Test
    void testReleaseReservation() {
        System.out.println("Running TC_004: Release Reservation");
        Reservation res = inventoryService.reserve(PROD_ID, 4);
        inventoryService.release(res.getId());

        // Stock was 10. Reserved 4 (Avail 6, Res 4). Released 4 (Avail 10, Res 0).
        InventoryItem item = inventoryRepository.findByProductId(PROD_ID).get();
        assertEquals(INITIAL_STOCK, item.getAvailableQty(), "Available stock must be fully restored after release.");
        assertEquals(0, item.getReservedQty(), "Reserved quantity must be cleared after release.");
    }

    @Test
    void testNegativeQuantity() {
        System.out.println("Running TC_005: Negative Quantity");
        // This tests the input validation logic within the reserve method.
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            inventoryService.reserve(PROD_ID, -1);
        });
        assertTrue(exception.getMessage().contains("Quantity must be positive."));
    }

    /**
     * TC_CON_006: Concurrency Test (Multi-threaded)
     * Proves the locking mechanism prevents overselling, addressing the CRITICAL risk.
     */
    @Test
    void testConcurrency() throws InterruptedException {
        System.out.println("Running TC_CON_006: Concurrency Test");

        // Setup: We have 10 units of stock.
        int requests = 20; // 20 simultaneous threads attempting reservation

        // Uses 10 worker threads to maximize simultaneous calls
        ExecutorService service = Executors.newFixedThreadPool(10);
        CountDownLatch latch = new CountDownLatch(requests);
        AtomicInteger successCount = new AtomicInteger(0);
        AtomicInteger failCount = new AtomicInteger(0);

        for (int i = 0; i < requests; i++) {
            service.submit(() -> {
                try {
                    // Each thread tries to reserve 1 unit atomically
                    inventoryService.reserve(PROD_ID, 1);
                    successCount.incrementAndGet();
                } catch (Exception e) {
                    failCount.incrementAndGet();
                } finally {
                    latch.countDown();
                }
            });
        }

        latch.await(); // Wait for all 20 threads to finish execution

        // Assertions: Exactly 10 must pass, and 10 must fail, ensuring stock integrity.
        assertEquals(INITIAL_STOCK, successCount.get(), "The number of successful reserves must equal the initial stock.");
        assertEquals(requests - INITIAL_STOCK, failCount.get(), "The number of failures must equal the excess requests.");

        InventoryItem item = inventoryRepository.findByProductId(PROD_ID).get();
        assertEquals(0, item.getAvailableQty(), "Final available stock must be zero (fully reserved).");
        assertEquals(INITIAL_STOCK, item.getReservedQty(), "Final reserved stock must equal the initial stock (10).");

        System.out.println("Concurrency Test Passed: " + successCount.get() + " successes, " + failCount.get() + " failures.");
    }
}