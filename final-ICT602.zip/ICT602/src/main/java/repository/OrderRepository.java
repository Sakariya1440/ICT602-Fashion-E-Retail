package repository;

import domain.Order;
import java.util.Optional;

/**
 * Repository Interface (Data Layer) for managing Order persistence.
 * This abstracts the database details away from the Service Layer.
 * * Note: Domain objects like 'Order' and 'OrderLine' must be defined in the 'domain' package.
 */
public interface OrderRepository {

    /**
     * Saves a new Order object to the persistence store.
     * @param order The Order aggregate to save.
     * @return The saved Order, potentially with a new ID assigned.
     */
    Order save(Order order);

    /**
     * Finds an Order by its unique identifier.
     * @param orderId The ID of the order.
     * @return An Optional containing the Order if found.
     */
    Optional<Order> findById(String orderId);

    // Other methods like finding orders by user ID could be added here.
}