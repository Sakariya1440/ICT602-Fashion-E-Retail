package repository;

import domain.InventoryItem;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.Map;

// This implementation allows the application to run without a real database.
public class InventoryRepositoryMemory implements InventoryRepository {
    private final Map<String, InventoryItem> items = new ConcurrentHashMap<>();

    @Override
    public Optional<InventoryItem> findByProductId(String productId) {
        return Optional.ofNullable(items.get(productId));
    }

    @Override
    public InventoryItem save(InventoryItem item) {
        items.put(item.getProductId(), item);
        return item;
    }

    // NOTE: This implementation is incomplete for a real system but sufficient for the demonstration.
}