package controller; // Using 'controller' package for simplicity

import service.OrderService;

/**
 * Presentation Layer: Acts as the entry point for a user request (e.g., hitting the /checkout API endpoint).
 * It delegates the business workflow to the OrderService.
 */
public class OrderController {
    private final OrderService orderService;

    public OrderController(OrderService orderService) {
        this.orderService = orderService;
    }

    /**
     * Simulates a user initiating a checkout for a hardcoded product and quantity.
     * This is the method run by MainApplication.
     */
    public void demo() {
        // Assume the user wants 2 units of P001.
        String productId = "P001";
        int quantity = 2;

        System.out.println("Placing order for " + quantity + " units of " + productId + "...");

        try {
            // Start the transaction (reserving stock and committing)
            orderService.placeOrder(productId, quantity);
            System.out.println("SUCCESS: Order completed and stock committed.");
        } catch (IllegalStateException e) {
            System.out.println("FAILURE: Checkout failed: " + e.getMessage());
        }
    }
}