package main; // Use a simple, non-specific package for the main entry point

import domain.InventoryItem;
import repository.InventoryRepository;
import repository.InventoryRepositoryMemory;
import service.InventoryService;
import service.OrderService;
import controller.OrderController;

// NOTE: You will need to copy the implementation of InventoryRepositoryMemory
// into a new file and ensure it implements InventoryRepository.
// For this example, we'll use a simple setup class to simulate the database.

public class MainApplication {

    public static void main(String[] args) {
        System.out.println("--- Starting Fashion E-Retail Demo Application ---");

        // --- 1. SETUP REPOSITORIES (Data Layer) ---
        // Assuming InventoryRepositoryMemory is implemented (see File 2 below)
        InventoryRepository inventoryRepo = new InventoryRepositoryMemory();

        // Initialize sample data: 10 units of Product P001
        inventoryRepo.save(new InventoryItem("P001", 10));
        System.out.println(">> Initial Stock for P001 set to 10 units.");

        // --- 2. SETUP SERVICES (Business Layer) ---
        InventoryService inventoryService = new InventoryService(inventoryRepo);
        // Note: For a real app, OrderRepository would also be injected here.
        OrderService orderService = new OrderService(inventoryService, null);

        // --- 3. SETUP CONTROLLER (Presentation Layer) ---
        OrderController orderController = new OrderController(orderService);

        // --- 4. EXECUTE DEMONSTRATION ---
        System.out.println("\n--- Running Demo Checkout Scenario ---");
        try {
            orderController.demo(); // Triggers the full placeOrder workflow

            // --- 5. VERIFY FINAL STATE ---
            InventoryItem item = inventoryRepo.findByProductId("P001").orElse(null);
            if (item != null) {
                System.out.println("\n--- Final Inventory State ---");
                System.out.println("P001 Available Stock: " + item.getAvailableQty());
                System.out.println("P001 Reserved Stock: " + item.getReservedQty());
            }

        } catch (IllegalStateException e) {
            System.err.println("DEMO FAILED: " + e.getMessage());
        }

        System.out.println("\n--- Demo Finished ---");
    }
}