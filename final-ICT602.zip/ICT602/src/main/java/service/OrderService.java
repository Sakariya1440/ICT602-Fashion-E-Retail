package service; // Matches the service package

import domain.Reservation;
import repository.OrderRepository;
// You need to import any domain classes like Order, OrderLine here if fully implemented.

/**
 * Service Layer: Coordinates the checkout business workflow.
 * It uses the InventoryService (the complex module) to handle stock.
 */
public class OrderService {
    private final InventoryService inventoryService;
    private final OrderRepository orderRepository; // Placeholder for future use

    // Note: The constructor accepts a placeholder for OrderRepository (null in MainApplication)
    public OrderService(InventoryService inventoryService, OrderRepository orderRepository) {
        this.inventoryService = inventoryService;
        this.orderRepository = orderRepository;
    }

    /**
     * Executes the full business transaction: reserve -> payment stub -> commit/release.
     */
    public void placeOrder(String productId, int quantity) {
        Reservation reservation = null;
        try {
            // 1. RESERVE INVENTORY (Calls complex module)
            reservation = inventoryService.reserve(productId, quantity);

            // 2. PAYMENT STUB (Simulates an external call)
            boolean paymentSuccess = true; // Hardcoded success for demo

            if (paymentSuccess) {
                // 3. COMMIT STOCK (Finalizes the sale)
                inventoryService.commit(reservation.getId());
                // Logic to save Order to database (using orderRepository) would go here
            } else {
                // 4. RELEASE STOCK (Rollback)
                inventoryService.release(reservation.getId());
                throw new IllegalStateException("Payment failed. Stock released.");
            }
        } catch (IllegalStateException | IllegalArgumentException e) {
            // Ensure any active reservation is released upon failure
            if (reservation != null) {
                inventoryService.release(reservation.getId());
            }
            throw e; // Re-throw exception to be caught by the Controller/MainApplication
        }
    }
}