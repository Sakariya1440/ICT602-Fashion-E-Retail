package domain;

import java.util.List;

/**
 * Domain Aggregate Root representing a customer's confirmed order.
 * This class is referenced by the OrderRepository and OrderService.
 */
public class Order {

    private final String id;
    private final String userId;
    private final List<Object> items; // Using Object placeholder for OrderLine for simplicity
    private final String status; // e.g., PENDING, PROCESSING, SHIPPED

    // Placeholder constructor for demonstration purposes
    public Order(String id, String userId, List<Object> items, String status) {
        this.id = id;
        this.userId = userId;
        this.items = items;
        this.status = status;
    }

    public String getId() {
        return id;
    }

    public String getUserId() {
        return userId;
    }

    // In a full implementation, OrderLine and OrderStatus classes would also be defined.
}